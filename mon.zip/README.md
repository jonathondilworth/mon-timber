# README.md | Mon Timber Example & Proposal

The current web design @ [Mon Timber]() is somewhat outdated. Furthermore, the shop has been implemented inappropriately, such that it no longer works.

A brief report has been compiled agaisnt SEO exaimination and the main issues associated with thr current website are:

1. No SSL Certificate (Effects Google Ranking)
2. Fairly slow mobile load pages (Fixable with AMP)
3. Low to Average Domain Authority (We'll look to fix this by adding more content that dynamically changes)

Please see the following Website Design For Mon Timber 

[Here](https://mon.dilworth.me/)

*bare in mind the text is simply there to placehold currently*

If the client is happy, I will continue to use [Laravel-MVC](https://laravel.com/), [Nova](https://nova.laravel.com/) and [Cashier](https://laravel.com/docs/8.x/billing).

If we're all happy thus far, we can continue soon!